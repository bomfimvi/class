package model.DAO;

public class NfDAO {
}
