package model.DAO;

public class FornecedorDAO {
}
