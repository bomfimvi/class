package model.DAO;

public class ClienteDAO {

    public void buscarCliente(){

    }
    public void novoCliente(){

    }
}
